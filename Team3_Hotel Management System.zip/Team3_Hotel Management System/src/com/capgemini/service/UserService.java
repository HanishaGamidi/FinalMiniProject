package com.capgemini.service;

import com.capgemini.exception.HotelException;

public interface UserService {

	
	int no_of_children = 0;
	int no_of_adults = 0;
	public void retrieveHotelDetails() throws HotelException;
	public boolean bookRooms(String room_id,String user_id,String booking_from,String booking_to,int no_of_adults,int no_of_children,double amount) throws HotelException;
	public double calculateAmount(String room_id,int no_of_days)throws HotelException;
	
}
